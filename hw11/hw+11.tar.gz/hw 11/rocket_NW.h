/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 rocket_NW rocket_NW.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:31:44
 * 
 * Image Information
 * -----------------
 * rocket_NW.jpg 61@56
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * Your difficulties will strengthen you.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef ROCKET_NW_BITMAP_H
#define ROCKET_NW_BITMAP_H

extern const unsigned short rocket_NW_palette[256];
#define ROCKET_NW_PALETTE_SIZE 256

extern const unsigned short rocket_NW[1708];
#define ROCKET_NW_SIZE 1708
#define ROCKET_NW_WIDTH 61
#define ROCKET_NW_HEIGHT 56

#endif

