/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 rocket_SW rocket_SW.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:31:52
 * 
 * Image Information
 * -----------------
 * rocket_SW.jpg 56@61
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * There's no such thing as an ordinary cat.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef ROCKET_SW_BITMAP_H
#define ROCKET_SW_BITMAP_H

extern const unsigned short rocket_SW_palette[256];
#define ROCKET_SW_PALETTE_SIZE 256

extern const unsigned short rocket_SW[1708];
#define ROCKET_SW_SIZE 1708
#define ROCKET_SW_WIDTH 56
#define ROCKET_SW_HEIGHT 61

#endif

