/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 title title.jpg 
 * Time-stamp: Tuesday 11/11/2014, 23:02:27
 * 
 * Image Information
 * -----------------
 * title.jpg 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * A C program is like a fast dance on a newly waxed dance floor by people carrying razors. - Waldi Ravens.
 * 
 * You will find great contentment in the daily, routine activities.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef TITLE_BITMAP_H
#define TITLE_BITMAP_H

extern const unsigned short title_palette[256];
#define TITLE_PALETTE_SIZE 256

extern const unsigned short title[19200];
#define TITLE_SIZE 19200
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

#endif

