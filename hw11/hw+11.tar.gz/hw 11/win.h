/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 win win.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:32:09
 * 
 * Image Information
 * -----------------
 * win.jpg 401@321
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * You will soon be surrounded by good friends and laughter.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef WIN_BITMAP_H
#define WIN_BITMAP_H

extern const unsigned short win_palette[256];
#define WIN_PALETTE_SIZE 256

extern const unsigned short win[64360];
#define WIN_SIZE 64360
#define WIN_WIDTH 401
#define WIN_HEIGHT 321

#endif

