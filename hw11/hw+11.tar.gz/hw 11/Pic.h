/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 Pic alien.jpg Win.jpg Lose.jpeg gameScreen.jpg title.jpg rocket_SW.jpg rocket_SE.jpg rocket_NE.jpg rocket_NW.jpg 
 * Time-stamp: Wednesday 11/12/2014, 01:13:28
 * 
 * Image Information
 * -----------------
 * alien.jpg 174@108
 * Win.jpg 275@172
 * Lose.jpeg 350@625
 * gameScreen.jpg 350@195
 * title.jpg 240@160
 * rocket_SW.jpg 56@61
 * rocket_SE.jpg 61@56
 * rocket_NE.jpg 56@61
 * rocket_NW.jpg 61@56
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * A C program is like a fast dance on a newly waxed dance floor by people carrying razors. - Waldi Ravens.
 * 
 * You will always be surrounded by true friends.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef PIC_BITMAP_H
#define PIC_BITMAP_H

extern const unsigned short Pic_palette[256];
#define PIC_PALETTE_SIZE 256

extern const unsigned short alien[9396];
#define ALIEN_SIZE 9396
#define ALIEN_WIDTH 174
#define ALIEN_HEIGHT 108

extern const unsigned short Win[23650];
#define WIN_SIZE 23650
#define WIN_WIDTH 275
#define WIN_HEIGHT 172

extern const unsigned short Lose[109375];
#define LOSE_SIZE 109375
#define LOSE_WIDTH 350
#define LOSE_HEIGHT 625

extern const unsigned short gameScreen[34125];
#define GAMESCREEN_SIZE 34125
#define GAMESCREEN_WIDTH 350
#define GAMESCREEN_HEIGHT 195

extern const unsigned short title[19200];
#define TITLE_SIZE 19200
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

extern const unsigned short rocket_SW[1708];
#define ROCKET_SW_SIZE 1708
#define ROCKET_SW_WIDTH 56
#define ROCKET_SW_HEIGHT 61

extern const unsigned short rocket_SE[1708];
#define ROCKET_SE_SIZE 1708
#define ROCKET_SE_WIDTH 61
#define ROCKET_SE_HEIGHT 56

extern const unsigned short rocket_NE[1708];
#define ROCKET_NE_SIZE 1708
#define ROCKET_NE_WIDTH 56
#define ROCKET_NE_HEIGHT 61

extern const unsigned short rocket_NW[1708];
#define ROCKET_NW_SIZE 1708
#define ROCKET_NW_WIDTH 61
#define ROCKET_NW_HEIGHT 56

#endif

