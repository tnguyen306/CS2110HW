/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 rocket_NE rocket_NE.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:31:33
 * 
 * Image Information
 * -----------------
 * rocket_NE.jpg 56@61
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * From now on your kindness will lead you to success.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef ROCKET_NE_BITMAP_H
#define ROCKET_NE_BITMAP_H

extern const unsigned short rocket_NE_palette[256];
#define ROCKET_NE_PALETTE_SIZE 256

extern const unsigned short rocket_NE[1708];
#define ROCKET_NE_SIZE 1708
#define ROCKET_NE_WIDTH 56
#define ROCKET_NE_HEIGHT 61

#endif

