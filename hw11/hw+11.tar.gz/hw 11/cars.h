/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 cars sportscar.jpg carGamePlay.jpeg 
 * Time-stamp: Tuesday 11/11/2014, 14:13:26
 * 
 * Image Information
 * -----------------
 * sportscar.jpg 1920@1200
 * carGamePlay.jpeg 284@177
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * It takes courage to admit fault.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef CARS_BITMAP_H
#define CARS_BITMAP_H

extern const unsigned short cars_palette[256];
#define CARS_PALETTE_SIZE 256

extern const unsigned short sportscar[1152000];
#define SPORTSCAR_SIZE 1152000
#define SPORTSCAR_WIDTH 1920
#define SPORTSCAR_HEIGHT 1200

extern const unsigned short carGamePlay[25134];
#define CARGAMEPLAY_SIZE 25134
#define CARGAMEPLAY_WIDTH 284
#define CARGAMEPLAY_HEIGHT 177

#endif

