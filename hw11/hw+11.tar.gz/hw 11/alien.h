/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 alien alien.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:30:30
 * 
 * Image Information
 * -----------------
 * alien.jpg 112@71
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * You make people realize that there exist other beauties in the world.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef ALIEN_BITMAP_H
#define ALIEN_BITMAP_H

extern const unsigned short alien_palette[184];
#define ALIEN_PALETTE_SIZE 184

extern const unsigned short alien[3976];
#define ALIEN_SIZE 3976
#define ALIEN_WIDTH 112
#define ALIEN_HEIGHT 71

#endif

