/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 rocket_SE rocket_SE.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:32:00
 * 
 * Image Information
 * -----------------
 * rocket_SE.jpg 61@56
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * You will always have good luck in your personal affairs.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef ROCKET_SE_BITMAP_H
#define ROCKET_SE_BITMAP_H

extern const unsigned short rocket_SE_palette[256];
#define ROCKET_SE_PALETTE_SIZE 256

extern const unsigned short rocket_SE[1708];
#define ROCKET_SE_SIZE 1708
#define ROCKET_SE_WIDTH 61
#define ROCKET_SE_HEIGHT 56

#endif

