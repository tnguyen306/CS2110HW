#include <stdlib.h>
#include <stdio.h>
#include "mylib.h"
#include "font.h"
#include "Pic.h"

#define NUMOBJS 3
#define MAXROW 14


enum {START, INSTRUCTIONS, WIN, GAME, LOSE};
enum {UP, DOWN, LEFT, RIGHT};
int start();
void instructions();
int game();
void win();
void lose();
/*int game();
void win();
void lose();*/


int main()
{	
	int seed = 0;
	int state = START;	
	while(1)
	{
		switch(state)
		{
		case START:
			seed = start();
			state = GAME;
			break;
		case GAME:
			game();
			state = GAME;
			break;
		case WIN:
			win();
			state = GAME;
			break;
		case LOSE:
			lose();
			state = GAME;
			break;
		case INSTRUCTIONS:
			instructions();
			state = game();
			break;
		default:
			break;
		}
	}
	return 0;
}

int start() {
	int seed = 0;
	REG_DISPCTL = MODE4 | BG2_ENABLE | BUFFER1FLAG;
	FlipPage();
	fill_palette(Pic_palette);
	drawImage4(0, 0, 240, 160, title);
	drawString4(90,10, "Galaxy", 13);
	drawString4(110,10, "Press enter for directions", 13);
	FlipPage();
	while(!KEY_DOWN_NOW(BUTTON_START) && !KEY_DOWN_NOW(BUTTON_DOWN)) {
		seed++;
	}
	if (KEY_DOWN_NOW(BUTTON_DOWN)) {
		//while(!KEY_DOWN_NOW(BUTTON_DOWN));
		instructions();
	}
	//while(KEY_DOWN_NOW(BUTTON_START));
	return seed;
}


void instructions() {
	
	REG_DISPCTL = MODE4 | BG2_ENABLE | BUFFER1FLAG;
	drawImage4(0, 0, 240, 160, gameScreen);
	drawString4(70,10, "Move with up, down, left, right", 250);
	drawString4(90,10, "Avoid aliens", 13);
	drawString4(110,10, "Goal is to cross to right", 13);
	drawString4(130,10, "Press enter to start playing", 13);
	FlipPage();
	while(!KEY_DOWN_NOW(BUTTON_START));
	while(KEY_DOWN_NOW(BUTTON_START));
}

int game() {	
	
	FlipPage();
	fillScreen4(0);
	//fill_palette(Pic_palette);
	REG_DISPCTL = MODE4 | BG2_ENABLE | BUFFER1FLAG;
	//drawImage4(0, 0, 240, 160, gameScreen);
	/*int scores = 3;
	int lives = 3;
	char buffer1[41];
	char buffer2[41];*/
	char buffer2[41];

	//Instantiate Rocket 
	ROCKET r, oldr;
	//Rocket oldr;
	//ROCKET *rocketPointer = &r;
	r.row = 100;
	r.col = 30;
	r.lives = 9;
	oldr = r;

	drawImage4(r.row, r.col, 40, 40, rocket_SW);
	
	//Instantiate the aliens
	ALIEN  al[NUMOBJS];
	//ALIEN oldA[NUMO];
	//ALIEN *ptr;
	int i;
	for (i = 0; i < NUMOBJS; i++) {
		al[i].row = 10 + 30*i;
		al[i].col = 10 +3 +40*i;
		//oldA[i] = al[i];
		drawImage4(al[i].row, al[i].col, 30, 30, alien);
	}	

	drawRect4(140, 220, 20, 20, 254);
	int m = 0;
	while(1) {	
		//int result = 0;
		//right maps to SW rocketship
		if(KEY_DOWN_NOW(BUTTON_RIGHT))
		{
			int found = 0;
			for (int i = 140; i < r.row + 20; i++) {
				//detecting a collission with alien (non-black)
				//Note that 254 is the color I passed in.
				if (videoBuffer[OFFSET(i, 220 + 40, 240)] == 254) {			
					//r.lives -= 1; //reduce the live upon collission with alien
					//sprintf(buffer1, "SCORE: %d", scores);
					win();
				}
		}
			if (found == 0) {
				oldr = r;
				drawRect4(oldr.row, oldr.col, 40, 40, 0);
				r.col += 1;
				drawImage4(r.row, r.col, 40, 40, rocket_SE);
		}
		}
			

		//left maps to SW ship
		if(KEY_DOWN_NOW(BUTTON_LEFT))
		{	
			int found = 0;
			for (int i = 140; i < r.row + 20; i++) {
				//detecting a collission with alien (non-black)
				if (videoBuffer[OFFSET(i, 220-1, 240)] == 254) {		
					//r.lives -= 1; //reduce the live upon collission with alien
					//sprintf(buffer1, "SCORE: %d", scores);
					win();
				}
		}
			if (found == 0) {
				oldr = r;
				drawRect4(oldr.row, oldr.col, 40, 40, 0);
				r.col -= 1;
				drawImage4(r.row, r.col, 40, 40, rocket_SW);
		}
			
		}

		//up maps to NW ship
		if(KEY_DOWN_NOW(BUTTON_UP))
		{	
			int found = 0;
			for (int i = 220; i < 220 + 20; i++) {
				//detecting a collission with alien (non-black)
				if (videoBuffer[OFFSET(140, i, 240)] == 254) {		
					//r.lives -= 1; //reduce the live upon collission with alien
					//sprintf(buffer1, "SCORE: %d", scores);
					win();
				}
		}
			if (found == 0) {
				oldr = r;
				drawRect4(oldr.row, oldr.col, 40, 40, 0);
				r.row -= 1;
				drawImage4(r.row, r.col, 40, 40, rocket_NW);
		}
		
		}

		//up maps to NW ship
		if(KEY_DOWN_NOW(BUTTON_DOWN))
		{	
			int found = 0;
			for (int i = 220; i < 220 + 20; i++) {
				//detecting a collission with alien (non-black)
				if (videoBuffer[OFFSET(140 + 20, i, 240)] == 254) {		
					//r.lives -= 1; //reduce the live upon collission with alien
					//sprintf(buffer1, "SCORE: %d", scores);
					win();
				}
		}
			if (found == 0) {
			oldr = r;
			drawRect4(oldr.row, oldr.col, 40, 40, 0);
			r.row += 1;
			drawImage4(r.row, r.col, 40, 40, rocket_NE);
			}
		
		}

		//pressing the select button makes the user go back
		//to the initial location where they started from 
		if(KEY_DOWN_NOW(BUTTON_SELECT))
		{	
			
				oldr = r;
				drawRect4(oldr.row, oldr.col, 40, 40, 0);
				r.row = 100;
				r.col = 30;
				r.lives = 9;
				drawImage4(r.row, r.col, 40, 40, rocket_SW);
			
		
		}
		if (r.lives == 0 || m > 908) {
			lose();
		}

		if (r.col > 230 && r.row > 130) {
			win();
		}
		
		sprintf(buffer2, "LIVES: %d", r.lives);
		waitForVblank();
		m++;
	}
	return 0;
}

void win() {
	REG_DISPCTL = MODE4 | BG2_ENABLE | BUFFER1FLAG;
	fillScreen4(0);
	FlipPage();
	drawImage4(0, 0, 240, 160, Win);
	drawString4(110,10, "Nice job!", 13);
	drawString4(130,10, "You win!", 13);
	FlipPage();
	while(!KEY_DOWN_NOW(BUTTON_START));
	while(KEY_DOWN_NOW(BUTTON_START));
}
void lose() {
	REG_DISPCTL = MODE4 | BG2_ENABLE | BUFFER1FLAG;
	fillScreen4(0);
	FlipPage();
	drawImage4(0, 0, 240, 160, Lose);
	drawString4(110,10, "Too slow", 13);
	drawString4(130,10, "You lose!", 13);
	FlipPage();
	while(!KEY_DOWN_NOW(BUTTON_START));
	while(KEY_DOWN_NOW(BUTTON_START));
}