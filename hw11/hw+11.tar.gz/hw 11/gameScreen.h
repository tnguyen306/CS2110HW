/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 gameScreen gameScreen.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:30:45
 * 
 * Image Information
 * -----------------
 * gameScreen.jpg 200@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * You are solid and dependable.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef GAMESCREEN_BITMAP_H
#define GAMESCREEN_BITMAP_H

extern const unsigned short gameScreen_palette[256];
#define GAMESCREEN_PALETTE_SIZE 256

extern const unsigned short gameScreen[16000];
#define GAMESCREEN_SIZE 16000
#define GAMESCREEN_WIDTH 200
#define GAMESCREEN_HEIGHT 160

#endif

