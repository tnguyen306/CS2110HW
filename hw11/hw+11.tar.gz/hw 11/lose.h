/*
 * Exported with brandontools v1.0
 * Invocation command was brandontools -mode4 lose lose.jpg 
 * Time-stamp: Tuesday 11/11/2014, 18:31:00
 * 
 * Image Information
 * -----------------
 * lose.jpg 454@283
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * To err is human... to really foul up requires the root password.
 * 
 * The first man gets the oyster, the second man gets the shell.
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef LOSE_BITMAP_H
#define LOSE_BITMAP_H

extern const unsigned short lose_palette[256];
#define LOSE_PALETTE_SIZE 256

extern const unsigned short lose[64241];
#define LOSE_SIZE 64241
#define LOSE_WIDTH 454
#define LOSE_HEIGHT 283

#endif

